# Escapism (Django)

A browser version of the escape-the-house text adventure, built as a
Django project. Same story and puzzles as the console version, played
through a web page instead of a terminal — with a home page, a
leaderboard, and a timed run.

## The story

Bedroom &rarr; hallway (five doors, one key fits) &rarr; living room
(couch, recliner, an old CRT TV, a bookshelf with a clue, a desk with
a computer) &rarr; kitchen (fridge, stove, sink, a locked door) &rarr;
garage (a car, a workbench, a claw machine, and a final lock that no
key fits).

## Setup (Windows, PowerShell)

1. Unzip this folder somewhere permanent, e.g.
   `C:\temp\Capstone\escapism_django\escapism`.
2. Open PowerShell and go to that folder:
   ```
   cd "C:\temp\Capstone\escapism_django\escapism"
   ```
3. Create and activate a virtual environment:
   ```
   python -m venv venv
   venv\Scripts\Activate.ps1
   ```
   (If PowerShell blocks the script, run
   `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` first,
   then try activating again.)
4. Install Django:
   ```
   pip install -r requirements.txt
   ```
5. Set up the database — this is what stores sessions AND the
   leaderboard (high scores). It's local, just a `db.sqlite3` file:
   ```
   python manage.py migrate
   ```
   If that complains instead of running cleanly, run
   `python manage.py makemigrations game` first, then `migrate` again.
6. Run the server:
   ```
   python manage.py runserver
   ```
7. Open your browser to **http://127.0.0.1:8000/**

Stop the server any time with `Ctrl+C` in the terminal.

## Playing again later

You don't need to repeat all the steps above — just steps 2, 3
(activate only, not create), 6, and 7:
```
cd "C:\temp\Capstone\escapism_django\escapism"
venv\Scripts\Activate.ps1
python manage.py runserver
```

## Admin access (reset leaderboard, create users)

Django ships with a built-in admin site at **`/admin/`**, and there's
an **admin** link in the top right of the home page that goes
straight there.

To use it, you first need one admin account (a "superuser"), created
once from the command line:
```
python manage.py createsuperuser
```
It'll ask for a username, email (optional, can leave blank), and
password. After that, log in at `http://127.0.0.1:8000/admin/` with
those credentials.

From there:
- **Reset the leaderboard** — go to *Game &rarr; High scores*. Select
  entries (or the checkbox in the header to select all), choose
  **"Reset leaderboard (delete selected scores)"** from the Action
  dropdown, and click Go.
- **Create more admin users** — go to *Authentication and
  Authorization &rarr; Users &rarr; Add user*. Check "Staff status" and
  "Superuser status" if they should also have full admin access.

## How it's laid out

- **`/`** — the title screen: game name, leaderboard (fastest escapes:
  name, date, time), and a **play** button.
- **`/play/`** — enter your name, then **start game**. This is the
  moment the clock starts.
- **`/game/`** — the game itself. A live clock ticks in the header.
  When you escape, your name, the date, and your time are saved to
  the leaderboard automatically, and you land on a finish screen with
  your final time.
- `game/logic.py` — the game engine (rooms, puzzles, the parser). All
  of the story and room text lives here — see "Changing the story"
  below.
- `game/models.py` — the `HighScore` table (name, seconds, when).
- `game/views.py` — ties it together: keeps game state in the
  visitor's session, times the run, and writes to the leaderboard the
  moment someone wins.
- `game/templates/game/` + `game/static/game/escapism.css` — the pages
  themselves, styled as an old amber terminal.

## Visual prototype: clickable bedroom scene

The bedroom now has a click-to-play scene above the text log — a small
SVG room (closet, nightstand, lamp, bed, exit door) where clicking an
object fires the exact same command the text parser already
understands. This is the prototype for turning Escapism into a
point-and-click adventure instead of a typed-command one.

**How it works, if you want to extend it to other rooms:**
- The illustration is hand-drawn SVG directly in
  `game/templates/game/escapism_game.html` (search for `<svg` — it starts
  right after the `{% if not won and loc == "bedroom" %}` line).
- Each clickable object is a `<g class="hotspot-group" onclick="sendCommand('...')">`.
  The string inside `sendCommand(...)` is a real game command — the
  same one you'd type. Clicking it fills the hidden text input and
  submits the existing form, so **no backend changes were needed at
  all** — `logic.py` and `views.py` don't know or care whether a
  command came from a click or from typing.
- A few pieces of the drawing react to game state (the lamp glows
  when on, the closet shows an open door once you've looked inside,
  the keys/hanger disappear once taken) — that's the `{% if lamp_on %}`
  / `{% if closet_open %}` style checks sprinkled through the SVG,
  fed by a few extra fields `views.py` now passes to the template.
- Styling for the scene (line color, hover glow) is in
  `game/static/game/escapism.css`, under the "Clickable scene" section
  near the bottom.

To add this to another room: copy the `{% if not won and loc == "..." %}`
block, draw a new SVG scene for that room using the same
`scene-line` / `scene-detail` / `hotspot-group` classes, and point
each hotspot's `sendCommand(...)` at the commands that room already
understands (check `do_<room>()` in `logic.py` for what those are).

## Changing the story

Everything lives in `game/logic.py`:

- **Room descriptions** — `describe_bedroom()`, `describe_hallway()`,
  `describe_living_room()`, `describe_kitchen()`, `describe_garage()`.
  Shown when you enter or `look` around a room.
- **Room logic / puzzles** — `do_bedroom()`, `do_hallway()`,
  `do_living_room()`, `do_kitchen()`, `do_garage()`. Look for
  `self.say("...")` lines — each one is a line of narration.
- **The password** — the `PASSWORD` constant near the top.
- **The escape itself** — `use_hanger_on_exit()`, at the very bottom.

Two things collected along the way currently don't unlock anything
yet: the page-253 bookmark code, and the computer login/README note.
They're there as flavor and red herrings for now — say the word if
you'd like either wired into a real lock somewhere in the house.

## Note on testing

I wasn't able to spin up a live Django server to click through
before handing this to you — my environment has no network access,
so `pip install django` can't run here. I tested everything I could
without it: every file compiles cleanly, and the whole game engine
(the same code the web views call) was run through a full scripted
playthrough of every room — bedroom through the final garage escape,
including the claw machine's two-attempt win condition — with correct
results. The web layer around it (views, sessions, the leaderboard,
templates) is written the standard way, but you're the first one
actually loading the pages. If you hit an error, paste it to me and
I'll fix it fast.
