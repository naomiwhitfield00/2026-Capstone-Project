import time

from django.shortcuts import render, redirect
from django.urls import reverse

from .logic import Game, new_state
from .models import HighScore


def home(request):
    scores = HighScore.objects.order_by("seconds", "completed_at")[:10]
    return render(request, "game/escapism_home.html", {"scores": scores})


def play(request):
    """Name-entry screen. Starts a fresh game + clock on submit."""
    if request.method == "POST":
        name = request.POST.get("player_name", "").strip()[:40] or "Anonymous"

        state = new_state()
        game = Game(state)
        game.describe()

        request.session["player_name"] = name
        request.session["start_time"] = time.time()
        request.session["state"] = game.to_state()
        request.session["log"] = [{"kind": "system", "text": t} for t in game.out]
        return redirect(reverse("game:index"))

    return render(request, "game/escapism_play.html")


def index(request):
    if "state" not in request.session:
        return redirect(reverse("game:play"))

    state = request.session["state"]
    log = request.session.get("log", [])

    elapsed_display = None
    elapsed_seconds = state.get("elapsed_seconds")
    if elapsed_seconds is not None:
        m, s = divmod(elapsed_seconds, 60)
        elapsed_display = f"{m}:{s:02d}"

    context = {
        "log": log,
        "won": state["won"],
        "awaiting": state["awaiting"],
        "player_name": request.session.get("player_name", "Player"),
        "start_time": request.session.get("start_time"),
        "elapsed_display": elapsed_display,
        "loc": state["loc"],
        "lamp_on": state.get("lamp_on"),
        "bed_made": state.get("bed_made"),
        "closet_open": state.get("closet_open"),
        "drawer_open": state.get("drawer_open"),
        "has_keys": "keys" in state.get("inv", []),
        "has_hanger": "hanger" in state.get("inv", []),
    }
    return render(request, "game/escapism_game.html", context)


def command(request):
    if request.method != "POST":
        return redirect(reverse("game:index"))

    text = request.POST.get("command", "")
    state = request.session.get("state")
    if state is None:
        return redirect(reverse("game:play"))

    game = Game(state)
    log = request.session.get("log", [])

    display_text = "*" * len(text) if state.get("awaiting") == "password" else text
    log.append({"kind": "input", "text": display_text})

    was_won = game.won
    game.handle(text)
    for line in game.out:
        log.append({"kind": "system", "text": line})

    new_state_dict = game.to_state()

    if game.won and not was_won:
        start = request.session.get("start_time")
        elapsed = int(time.time() - start) if start else 0
        new_state_dict["elapsed_seconds"] = elapsed
        name = request.session.get("player_name", "Anonymous")
        HighScore.objects.create(player_name=name, seconds=elapsed)
    elif game.won:
        new_state_dict["elapsed_seconds"] = state.get("elapsed_seconds")

    request.session["state"] = new_state_dict
    request.session["log"] = log
    return redirect(reverse("game:index"))


def new_game(request):
    for key in ("state", "log", "start_time", "player_name"):
        request.session.pop(key, None)
    return redirect(reverse("game:play"))
