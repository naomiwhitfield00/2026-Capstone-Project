from django.contrib import admin

from .models import HighScore


@admin.action(description="Reset leaderboard (delete selected scores)")
def reset_scores(modeladmin, request, queryset):
    queryset.delete()


@admin.register(HighScore)
class HighScoreAdmin(admin.ModelAdmin):
    list_display = ("player_name", "minutes_seconds", "completed_at")
    ordering = ("seconds", "completed_at")
    actions = [reset_scores]
