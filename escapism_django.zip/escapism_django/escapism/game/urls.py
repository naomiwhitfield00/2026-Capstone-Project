from django.urls import path

from . import views

app_name = "game"

urlpatterns = [
    path("", views.home, name="home"),
    path("play/", views.play, name="play"),
    path("game/", views.index, name="index"),
    path("game/command/", views.command, name="command"),
    path("game/new/", views.new_game, name="new_game"),
]
